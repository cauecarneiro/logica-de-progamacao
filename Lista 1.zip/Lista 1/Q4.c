#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(){
	setlocale(0,"Portuguese");
	float salario, novo_salario;
	
	printf("Insira o sal�rio do funcion�rio: ");
	scanf("%f", &salario);
	
	printf("\nNOVO SAL�RIO �POS REAJUSTE DE 25%%");
	novo_salario = salario * 25/100 + salario;
	printf("\nNovo Sal�rio: %.2f", novo_salario);
	
	return 0;
}
