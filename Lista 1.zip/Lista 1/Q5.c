#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(){
	setlocale(0,"Portuguese");
	float salario, novo_salario, porcentagem_aumento;
	
	printf("Insira o sal�rio do funcion�rio: ");
	scanf("%f", &salario);
	
	printf("Isira a porcentagem de aumento: ");
	scanf("%f", &porcentagem_aumento);
	
	novo_salario = salario * porcentagem_aumento/100 + salario;
	
	printf("Novo sal�rio: %.2f", novo_salario);
	
	return 0;
}
