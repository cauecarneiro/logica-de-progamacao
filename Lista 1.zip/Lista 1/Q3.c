#include <stdio.h>
#include <locale.h>

int main(){
	setlocale(0,"Portuguese");
	float n1, n2, n3, p1, p2, p3, media;
	
	printf("Nota 1: ");
	scanf("%f", &n1);
	printf("Peso da nota 1: ");
	scanf("%f", &p1);
	
	printf("\nNota 2: ");
	scanf("%f", &n2);
	printf("Peso da nota 2: ");
	scanf("%f", &p2);
	
	printf("\nNota 3: ");
	scanf("%f", &n3);
	printf("Peso da nota 3: ");
	scanf("%f", &p3);
	
	media = ((n1*p1) + (n2*p2) + (n3*p3)) / 10;
	
	printf("M�dia ponderada: %.2f", media);
	
	return 0;
}
