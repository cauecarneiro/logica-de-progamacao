#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(){
	setlocale(LC_ALL, "Portuguese");
	float salario_base, salario_receber, imposto;
	
	printf("Sal�rio Base: ");
	scanf("%f", &salario_base);
	
	imposto = salario_base * 10/100;
	salario_receber = salario_base + 50 - imposto;
	
	printf("Sal�rio a receber �pos reajustes: %.2f", salario_receber);
}
