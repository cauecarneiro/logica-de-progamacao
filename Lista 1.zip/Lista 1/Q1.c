#include <stdio.h>
#include <locale.h>

int main(){
	setlocale(0,"Portuguese");
	float n1, n2, n3, n4, soma;
	
	printf("N�mero 1: ");
	scanf("%f", &n1);

	printf("N�mero 2: ");
	scanf("%f", &n2);
	
	printf("N�mero 3: ");
	scanf("%f", &n3);
	
	printf("N�mero 4: ");
	scanf("%f", &n4);
	
	soma = n1+n2+n3+n4;
	
	printf("Soma = %.2f", soma);
	
	return 0;
}
