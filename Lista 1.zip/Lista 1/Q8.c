#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(){
	setlocale(0,"Portuguese");
	
	float deposito, taxa, rendimento, saldo_final;
	
	printf("Valor dep�sito: ");
	scanf("%f", &deposito);
	fflush(stdin);
	
	printf("Valor taxa: ");
	scanf("%f", &taxa);
	fflush(stdin);
	
	rendimento = deposito * taxa/100;
	saldo_final = deposito + deposito * taxa/100;
	
	printf("Rendimento %.2f", rendimento);
	printf("\nSaldo final %.2f", saldo_final);
	
	return 0;
}
